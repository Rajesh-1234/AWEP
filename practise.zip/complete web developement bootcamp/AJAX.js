console.log("AJAX tutorial in one video"); 


let fetchbtn = document.getElementById('fetchbtn');
fetchbtn.addEventListener('click',buttonclickhandler)

function buttonclickhandler(){6
    console.log('you have clicked the fetchbtn');
    // instantiate an xhr Object
    const xhr = new XMLHttpRequest();

    // open the object 
    // xhr.open('GET', 'Raj.txt', true);
    // xhr.open('GET', 'https://jsonplaceholder.typicode.com/todos/1', true);

    // use this for post request 
    xhr.open('POST', 'http://dummy.restapiexample.com/api/v1/create', true);
    xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');

    // what to do on progress (optional)
    xhr.onprogress = function(){
        console.log('on progress');
    }



    // xhr.onreadystatechange = function(){
    //     console.log('ready state is', xhr.readyState);
    // }
   // what to do when responce is ready
    xhr.onload = function(){
        if(this.status === 200){
        console.log(this.responseText)
        }
        // else{
        //     console.error("some error occured");
        // }
    }

    // send the Response
    Params = "name=test&salary=123&age=23";	

    xhr.send(Params);

    console.log("we are done");
}

let popbtn = document.getElementById('pophandler');
popbtn.addEventListener('click',pophandler);

function pophandler(){
    console.log('you have clicked the pop handler');
    // instantiate an xhr Object
    const xhr = new XMLHttpRequest();

    // open the object 
    // xhr.open('GET', 'Raj.txt', true);
    xhr.open('GET', 'http://dummy.restapiexample.com/api/v1/employees', true);

    
   // what to do when responce is ready
    xhr.onload = function(){
        if(this.status === 200){
        let obj=JSON.parse(this.responseText);
        console.log(obj);
        }
         else{
             console.error("some error occured");
        }
    }

    // send the Response
    xhr.send();

    console.log("we are done fetching employee");


}