
  var count = 0;

  function increment()
  {

       var a = document.querySelector("#counter1");

         count ++;

         a.innerHTML=count;

  }