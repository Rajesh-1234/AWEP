

   var count = 0; 

  function increment()
  {
     

      var a = document.querySelector("#myclass");

      count++;

      a.innerHTML= "Like" + "  " + count;
  }

    function readbox()
    {

           let read = document.querySelector("#id1").value;

           let a = document.querySelector("#commentref");

            // a.innerHTML=read;   ----> comment when other commnet overides 

            var newdiv  = document.createElement('div');

             document.querySelector("#id1").value=" ";

              newdiv.textContent = read;

             a.insertBefore(newdiv,a.firstChild)
        




    }

      function deletediv(a)
      {
    
           
      }