
var counter = 1;

function increment()
{
    var a = document.querySelector("#counterid");

      counter=counter+1;

      a.innerHTML=counter;
}

  function decrement()

  {

      var a = document.querySelector("#counterid");

       counter = counter-1;

       a.innerHTML=counter;

  }